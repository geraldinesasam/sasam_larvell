<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>Social Media</h3>

              <div class="panel panel-default">
                <center>
          				Facebook: https://www.facebook.com/hyrum.cinco.7<BR><BR>
            </center>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>