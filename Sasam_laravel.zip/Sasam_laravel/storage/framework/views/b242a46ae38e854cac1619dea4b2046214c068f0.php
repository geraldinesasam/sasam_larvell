<?php $__env->startSection("content"); ?>
  <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	 <h2>About PHP-2</h2>
              <div class="panel panel-default">
              	This subject is more on interacting frameworks especially object oriented programming<BR><BR>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>