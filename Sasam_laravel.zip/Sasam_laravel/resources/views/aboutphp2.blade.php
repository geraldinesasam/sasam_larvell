@extends('layouts.app2')

@section("content")
  <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	 <h3>About PHP-2</h3>
           <center>
              <div class="panel panel-default">
              	PHP is a server-side scripting language designed primarily for web development but also used as a general-purpose programming language.<BR><BR>
				PHP originally stood for Personal Home Page, but it now stands for the recursive acronym PHP: Hypertext Preprocessor.<BR><BR>
                           <BR><BR>
            </div>
              </center>
            </div>
        </div>
    </div>
</div>
@stop