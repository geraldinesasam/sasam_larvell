@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>About</h3>

              <div class="panel panel-default">
                <center>
              
        				  My name is Geraline G. Sasam<BR><BR>
        				  I'm Snow White and I feed on apples that kill me.<BR><BR>
        				  I'm Ariel out on the Mediterranean sea.<BR><BR>
        				  I'm Pocahontas, as free as thee and Princess Jasmine on that royal family tree.<BR><BR>
        				  I'm Belle whose standout is inner beauty and Mulan, brave and selfless of whom does her duty.<BR><BR>
        				  I'm Rapunzel whose hair is lengthy, and Aurora whose fate was unlucky.<BR><BR>
        				  I'm Minnie Mouse finding her Mickey and Cinderella who proved to be plucky.<BR><BR>
        				  I'm a fairytale that starts with petty then grows into a sudden confetti.<BR><BR>
        				  I am a mix and clash of Disney characters so silly, it's almost synonyms with infinity.<BR><BR>
        				  Twenty years of big dreams and twigged streams.<BR><BR>
        				  Twenty years of seeing coal-dark steams transform into white-bright gleams.<BR><BR>
        				  Twenty years of walking under the sun and it hasn't even begun<BR><BR>
        				  Sometimes, the light's too bright, sometimes, the grip's too tight,<BR><BR>
        				  but everything will be alright, nobody will make it out.<BR><BR>
        				  You can't always believe what you see.<BR><BR>
        				  Things aren't always what they appear to be.<BR><BR>
        				  I am an old soul and curiousity is my second name<BR><BR>
        				  There's a magic in the distance, where the sea-line meets the sky<BR><BR>
        				  My goal in this life is to obtain the higest blessings<BR><BR>
        				  I'm own my way for my future.
              
              </center>
              </div>
            </div>
        </div>
    </div>
</div>

@stop